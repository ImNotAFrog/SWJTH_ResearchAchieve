/*
* @Author: MaiBenBen
* @Date:   2018-02-13 17:07:07
* @Last Modified by:   MaiBenBen
* @Last Modified time: 2018-02-16 17:41:44
*/
window.onload = function(){
	var userIcon = document.getElementsByClassName("portrait-wrap")[0],
		userCenter = document.getElementsByClassName("user-center")[0],
		oUserInfo = document.getElementsByClassName("user-info")[0],
		oFormHead	= document.getElementsByClassName("form-head")[0],
		oEdit		= oFormHead.getElementsByTagName("span")[2],
		oUpdateBtn  = oUserInfo.getElementsByClassName("update-btn")[0],
		wait   = null;

	/*头像部分的事件*/
	userIcon.onmouseover = function(){
		userCenter.style.display = "block";
	}
	userIcon.onmouseout  = function(){
	 	wait = setTimeout(function(){
	 		userCenter.style.display = "none";
	 	},2000);
	}
	userCenter.onmouseover = function(){
	 	clearTimeout(wait);
	 	userCenter.style.display = "block";
	}
	userCenter.onmouseout  = function(){
	 	userCenter.style.display = "none";
	}

	/*编辑表单的事件*/
	oEdit.onclick = function(){
		oUpdateBtn.style.display = "block";
	}

};